﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels;

public partial class ViewModelBase : ObservableObject
{
}