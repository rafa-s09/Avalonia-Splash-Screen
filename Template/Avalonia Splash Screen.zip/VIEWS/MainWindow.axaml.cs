using Avalonia.Controls;

namespace $safeprojectname$.View;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}